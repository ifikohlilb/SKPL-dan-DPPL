/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ohlib;

/**
 *
 * @author NURUL DIAN K
 */
public class buku {
    private String Id_Buku;
    private String Judul;
    private String Penulis;
    private String Penerbit;
    private String Genre;
    private String Sinopsis;

    public buku(String Id_Buku, String Judul, String Penulis, String Penerbit, String Genre, String Sinopsis) {
        this.Id_Buku = Id_Buku;
        this.Judul = Judul;
        this.Penulis = Penulis;
        this.Penerbit = Penerbit;
        this.Genre = Genre;
        this.Sinopsis = Sinopsis;
    }

    public String getId_Buku() {
        return Id_Buku;
    }

    public void setId_Buku(String Id_Buku) {
        this.Id_Buku = Id_Buku;
    }

    public String getJudul() {
        return Judul;
    }

    public void setJudul(String Judul) {
        this.Judul = Judul;
    }

    public String getPenulis() {
        return Penulis;
    }

    public void setPenulis(String Penulis) {
        this.Penulis = Penulis;
    }

    public String getPenerbit() {
        return Penerbit;
    }

    public void setPenerbit(String Penerbit) {
        this.Penerbit = Penerbit;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String Genre) {
        this.Genre = Genre;
    }

    public String getSinopsis() {
        return Sinopsis;
    }

    public void setSinopsis(String Sinopsis) {
        this.Sinopsis = Sinopsis;
    }
    
    
}
