/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ohlib;

/**
 *
 * @author NURUL DIAN K
 */
public class lomba  extends perpustakaan{

    public lomba(String Id_informasi, String Judul, String Tanggal, String Deskripsi) {
        super(Id_informasi, Judul, Tanggal, Deskripsi);
    }
    
}
