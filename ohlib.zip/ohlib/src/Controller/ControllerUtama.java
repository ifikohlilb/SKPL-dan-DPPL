/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author NURUL DIAN K
 */

import Model.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import view.TampilanMenuUtama;
import view.TampilanLogin;

public class ControllerUtama implements ActionListener{
    private TampilanLogin login;
    private TampilanMenuUtama main;
    
    public ControllerUtama(){
        main = new TampilanMenuUtama();
        main.addActionListener(this);
        main.setVisible(true);
    }
    
   
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
        if (source.equals(main.getBtnAdmin())){
            
        } else if (source.equals(main.getBtnPengguna())){
            ControllerLogin obj = new ControllerLogin();
        } else if (source.equals(main.getBtnKeluar())){
            JFrame frame = new JFrame();
            if (JOptionPane.showConfirmDialog(frame,"Apakah Anda Yakin?","Selesai",JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION){
             System.exit(0);
            
        }
    }
}
}
