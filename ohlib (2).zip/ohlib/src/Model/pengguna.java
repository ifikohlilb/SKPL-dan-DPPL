/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author NURUL DIAN K
 */
public class pengguna {
    private String Id_pengguna;
    private String Nama;
    private String Email;
    private char Gender;
    private akun akunPengguna;

    public pengguna(String Id_pengguna, String Nama, String Email, char Gender, akun akunPengguna) {
        this.Id_pengguna = Id_pengguna;
        this.Nama = Nama;
        this.Email = Email;
        this.Gender = Gender;
        this.akunPengguna = akunPengguna;
    }

    public akun getAkunPengguna() {
        return akunPengguna;
    }

    public String getId_pengguna() {
        return Id_pengguna;
    }

    public void setId_pengguna(String Id_pengguna) {
        this.Id_pengguna = Id_pengguna;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String Nama) {
        this.Nama = Nama;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public char getGender() {
        return Gender;
    }

    public void setGender(char Gender) {
        this.Gender = Gender;
    }
    
}


