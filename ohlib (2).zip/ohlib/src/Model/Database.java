/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author NURUL DIAN K
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Database {
    private Connection conn = null;
    private Statement stmt = null;
    private ResultSet rs = null;
   // private ArrayList<> pembayaran= new ArrayList<>();

    public Database() {
        loadPembayaran();
    }
    
    public void connect() {
        try {
            String url = "jdbc:mysql://localhost:3306/zakat";
            String user = "root";
            String pass = "Kusumawati123";
            conn = DriverManager.getConnection(url, user, pass);
            stmt = conn.createStatement();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    public void disconnect(){
        try {
            conn.close();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public boolean manipulate(String query){
        boolean cek = false;
        try {
            int rows = stmt.executeUpdate(query);
            if (rows > 0) cek = true;
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cek;
    }
    
    public void loadPembayaran() {
        connect();
        try {
            String query = "SELECT * FROM pembayaran;";
            rs = stmt.executeQuery(query);
            while (rs.next()){
                /*.add(new Pembayaran(rs.getString("ID"), rs.getString("nama"), rs.getString("email"), rs.getString("lokasi"),rs.getString("jenis"),
                        rs.getString("jumlah"),rs.getString("total"),rs.getString("jenisPembayaran"),rs.getString("status")));*/
            }
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        disconnect();
    }

    /*public ArrayList<> getPembayaran() {
        return pembayaran;
    }*/
    
    /*public void addPembayaran( m) {
        connect();
        String query = "INSERT INTO  VALUES (";
        
    }*/
     
    public boolean cekDuplikatID(String ID){
        boolean cek = false;
        /*for (Pembayaran p : pembayaran) {
            if (p.getID().equals(ID)){
                cek = true;
                break;
            }
        }*/
        return cek;
    }
    
    /*public void delPembayaran(String ID) {
        connect();
        String query = "DELETE FROM pembayaran WHERE ID='" + ID + "'";
        if (manipulate(query)){
            for (Pembayaran p : pembayaran) {
                if (p.getID().equals(ID)){
                    pembayaran.remove(p);
                    break;
                }
            }
        }
        disconnect();
    }
    
    public void updatePembayaran(Pembayaran p) {
        connect();
        String query = "UPDATE pembayaran SET";
        query += " status='" + p.getStatus() + "',";
        query += " WHERE ID='" + p.getID() + "'";
        if (manipulate(query)){
            for (Pembayaran pm : pembayaran) {
                if (pm.getID().equals(p.getID())){
                    pm.setStatus(p.getStatus());
                    break;
                }
            }
        }
        disconnect();
    }    
}
