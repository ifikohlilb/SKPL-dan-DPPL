/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author NURUL DIAN K
 */
public class admin {
    private String Id_admin;
    private String nama;
    private String email;
    private akun akunAdmin;

    public admin(String Id_admin, String nama, String email, akun akunAdmin) {
        this.Id_admin = Id_admin;
        this.nama = nama;
        this.email = email;
        this.akunAdmin = akunAdmin;
    }

    public String getId_admin() {
        return Id_admin;
    }

    public void setId_admin(String Id_admin) {
        this.Id_admin = Id_admin;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
}
