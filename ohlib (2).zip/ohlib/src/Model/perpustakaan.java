/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author NURUL DIAN K
 */
public class perpustakaan {
   private String Id_informasi;
   private String Judul;
   private String Tanggal;
   private String Deskripsi;

    public perpustakaan(String Id_informasi, String Judul, String Tanggal, String Deskripsi) {
        this.Id_informasi = Id_informasi;
        this.Judul = Judul;
        this.Tanggal = Tanggal;
        this.Deskripsi = Deskripsi;
    }
   
    public String getId_informasi() {
        return Id_informasi;
    }

    public void setId_informasi(String Id_informasi) {
        this.Id_informasi = Id_informasi;
    }

    public String getJudul() {
        return Judul;
    }

    public void setJudul(String Judul) {
        this.Judul = Judul;
    }

    public String getTanggal() {
        return Tanggal;
    }

    public void setTanggal(String Tanggal) {
        this.Tanggal = Tanggal;
    }

    public String getDeskripsi() {
        return Deskripsi;
    }

    public void setDeskripsi(String Deskripsi) {
        this.Deskripsi = Deskripsi;
    }
   
   
}
