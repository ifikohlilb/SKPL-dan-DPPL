/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.*;
import java.awt.event.*;
import java.util.*;
import java.awt.event.ActionListener;
import view.DetailBuku;
/**
 *
 * @author NURUL DIAN K
 */
public class ControllerDetailBuku implements ActionListener {
    private DetailBuku detail;
    private Database db;
    
    public ControllerDetailBuku(){
        detail = new DetailBuku();
        db = new Database();
        detail.addActionListener(this);
        detail.setVisible(true);
    }
    
    
}
