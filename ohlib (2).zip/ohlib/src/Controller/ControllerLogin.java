/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author NURUL DIAN K
 */

import Model.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import view.TampilanLogin;
import view.TampilanPengguna;
import view.TampilanMenuUtama;

public class ControllerLogin implements ActionListener {
    private TampilanLogin login;
    private Database db;
    
    public ControllerLogin(){
        login = new TampilanLogin();
        db = new Database();
        login.addActionListener(this);
        login.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
        if (source.equals(login.getBtnLogin())){
             ControllerPengguna obj = new ControllerPengguna();
        } else if (source.equals(login.getBtnKembali())){
            ControllerUtama c = new ControllerUtama();
        }
    }
}
