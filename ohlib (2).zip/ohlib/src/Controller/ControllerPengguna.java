/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author NURUL DIAN K
 */
import Model.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import view.KelolaAkun;

public class ControllerPengguna implements ActionListener {
   
    private Tamplilan amil;
    private Database db;
    
    public ControllerAmil(){
        amil = new ViewAmil();
        db = new Database();
        amil.addActionListener(this);
        amil.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
        if (source.equals(amil.getBtnOK())){
            btnOKActionPerformed();
        } else if (source.equals(amil.getBtnSimpan())){
            btnSimpanActionPerformed();
        } else if (source.equals(amil.getBtnKembali())){
            ControllerUtama c = new ControllerUtama();
        }
    }
    
    public void loadTable(){
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Nama", "Email", "Lokasi", "Jenis Zakat", "Jumlah", "Total", "Jenis Pembayaran", "Status"}, 0);
        ArrayList<Pembayaran> pembayaran = db.getPembayaran();
        for (Pembayaran p : pembayaran) {
            model.addRow(new Object[]{p.getID(),p.getNama(),p.getEmail(),p.getLokasi(),p.getJenis(),p.getJumlah(),p.getTotal(),p.getJenisPembayaran(),p.getStatus()});
        }
        amil.setTbPembayaran(model);
    }
    
    public void tbPembayaranActionPerformed(){
        db.loadPembayaran();
        ViewMuzakki m = new ViewMuzakki();
        DefaultTableModel model = (DefaultTableModel)amil.getTbPembayaran().getModel();
        if (m.getButtonGroup1().getSelection().getActionCommand()=="Tunai"){
            model.addRow(new Object[]{m.getTxtID(),m.getTxtNama(),m.getTxtEmail(),m.getCmbLokasi().getSelectedItem().toString(),
                m.getCmbJenis().getSelectedItem().toString(),m.getTxtJumlah(),m.getTxtTotal(),m.getButtonGroup1().getSelection().getActionCommand(),false});
        } else {
            model.addRow(new Object[]{m.getTxtID(),m.getTxtNama(),m.getTxtEmail(),m.getCmbLokasi().getSelectedItem().toString(),
                m.getCmbJenis().getSelectedItem().toString(),m.getTxtJumlah(),m.getTxtTotal(),m.getButtonGroup1().getSelection().getActionCommand(),true});
        }
    }
    
    public void btnOKActionPerformed(){
        
        String idAmil = amil.getTxtIdAmil();
        if (idAmil.contains("A01") || idAmil.contains("A02") || idAmil.contains("A03") || idAmil.contains("A05")){
           loadTable();
        } else {
           amil.getTbPembayaran().setVisible(false);
        }
    }
    
    public void btnSimpanActionPerformed(){
        
    }
}
}
