/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.*;
import java.awt.event.*;
import java.util.*;
import java.awt.event.ActionListener;
import view.formPeminjaman;

/**
 *
 * @author NURUL DIAN K
 */
public class ControllerFormPeminjaman implements ActionListener{
    private formPeminjaman form;
    
    public ControllerFormPeminjaman(){
        form = new formPeminjaman();
        form.addActionListener(this);
        form.setVisible(true);
    }
}
